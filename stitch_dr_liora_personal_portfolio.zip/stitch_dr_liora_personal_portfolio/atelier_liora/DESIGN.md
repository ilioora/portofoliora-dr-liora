---
name: Atelier Liora
colors:
  surface: '#fcf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fcf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e5e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#45464d'
  inverse-surface: '#31312d'
  inverse-on-surface: '#f3f0ea'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#00668a'
  on-secondary: '#ffffff'
  secondary-container: '#40c2fd'
  on-secondary-container: '#004d6a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#221a0f'
  on-tertiary-container: '#8e8272'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#efe0cd'
  tertiary-fixed-dim: '#d3c4b2'
  on-tertiary-fixed: '#221a0f'
  on-tertiary-fixed-variant: '#4f4537'
  background: '#fcf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e5e2dc'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 1.875rem
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 1.375rem
    fontWeight: '500'
    lineHeight: '1.4'
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: '1.5'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.7'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.65'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-desktop: 3.5rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system expresses a refined medical editorial aesthetic: authoritative yet deeply human, calm, and welcoming. Designed for a contemporary general practitioner whose life extends beyond clinic walls into swimming, canine companionship, and holistic wellness, the visual identity harmonizes clinical gravitas with warm, personal intimacy.

The visual style blends **Editorial Minimalism** with subtle **Warm Tactility**:
- Crisp editorial typographic rhythm balancing high-contrast serif headlines with a soft, legible modern sans-serif body.
- Generous breathing room, evoking mental clarity, quiet competence, and tranquil medical care.
- Restrained, intentional interactions with gentle transitions that feel reassuring rather than sterile or overly commercial.

## Colors

The palette establishes an atmosphere of pristine professional excellence layered over soothing, organic warmth:

- **Primary (`#0F172A` - Midnight Slate / Deep Navy):** Represents clinical authority, intellect, and timeless poise. Used for primary typography, dominant callouts, and anchoring framing elements.
- **Secondary (`#38BDF8` - Ice Sky Blue):** Echoes clear waters, breath, vitality, and clinical freshness. Used for active badges, interactive highlights, and focal accents without introducing digital noise.
- **Tertiary (`#EADBC8` - Warm Biscuit / Sand):** Infuses gentle compassion, domestic comfort, and tactile warmth. Applied to delicate borders, muted pill fills, and soft supportive cards.
- **Neutral Surface (`#F7F4EE` - Linen Alabaster):** Replaces harsh cold whites on background canvases, reducing visual fatigue while lending an artisanal, editorial quality. Contrast with pure white (`#FFFFFF`) containers creates natural dimensional layering.

## Typography

Typography establishes an intimate dialogue between classic scholarship and modern warmth:

- **Headlines (Playfair Display):** Conveys the established tradition of medicine and humanistic care. Used for hero titles, section titles, and thematic quote callouts. Italic cuts may be applied selectively to single evocative words (e.g., *healing*, *compassion*, *balance*).
- **Body & Functional Copy (Plus Jakarta Sans):** Offers crisp, contemporary legibility with geometric curves that remain approachable.
- **Labels & Microcopy:** Rendered with elevated tracking to retain clarity and order across clinical credentials, dates, tags, and navigation indices.

## Layout & Spacing

The layout is built upon an open 12-column grid on desktop and a flexible 4-column structure on mobile devices, optimized for narrative flow and portfolio presentation:

- **Desktop (min-width: 1024px):** 12-column fluid grid, centered within a max-width of `1280px`. Margins maintain `3.5rem`, providing generous breathing room alongside a `2.5rem` gutter between modular columns.
- **Tablet (768px – 1023px):** 8-column grid with `2rem` margins and `1.5rem` gutters.
- **Mobile (< 768px):** 4-column layout with `1.25rem` outer canvas padding and compact vertical rhythm.
- **Rhythm:** Spacing follows an intentional asymmetric cadence—long editorial pauses (via `space-xl`) between distinct thematic vignettes (Medical Practice, Lifestyle & Passion, Patient Care Philosophy) and tight component clusters (`space-xs` and `space-sm`) inside credentials and metric groups.

## Elevation & Depth

Visual depth avoids artificial glossy drops or stark synthetic drop-shadows. Hierarchy is achieved through warm physical layering and soft ambient luminosity:

- **Canvas Foundation:** Layered baseline using `#F7F4EE` (Linen Alabaster), punctuated by crisp floating surface planes of `#FFFFFF`.
- **Ambient Shadows:** Cast using deep navy tones diluted to near-imperceptible intensities:
  - *Subtle Card Elevation:* `0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 1px 3px 0 rgba(15, 23, 42, 0.02)`
  - *Floating Interactive / Modal Elevation:* `0 20px 40px -8px rgba(15, 23, 42, 0.08), 0 4px 12px 0 rgba(15, 23, 42, 0.03)`
- **Atmospheric Boundaries:** In place of heavy dividers, elements are structured with hairline borders tinted with `#EADBC8` or translucent primary slate (`rgba(15, 23, 42, 0.06)`).

## Shapes

The shape system employs roundedness level `2`, harmonizing architectural precision with gentle, organic friendliness:

- **Base Radius (0.5rem / `rounded-md`):** Applied to compact inputs, badge indicators, and inner action items.
- **Container Radius (1rem / `rounded-lg`):** Governs interactive cards, testimonial enclosures, and biographical feature boxes.
- **Statement Radius (1.5rem / `rounded-xl`):** Dedicated to featured hero imagery, narrative profile highlights, and lifestyle galleries (e.g., personal swimming memoirs and canine portraits), evoking tactile smoothness.

## Components

### Buttons
- **Primary Action:** Solid `#0F172A` background, `#FFFFFF` text, `0.5rem` radius. Subtle hover state transition shifting to deep slate `#1E293B` with micro-lift.
- **Secondary / Soft Action:** Subtle `#E8F2F8` ice-blue wash, `#0F172A` label, zero-border; darkens softly on hover.
- **Editorial Text Link:** Understated inline link in `#0F172A` with a gentle `#38BDF8` underline offset by 4px.

### Cards & Narrative Modules
- **Clinical & Credentials Card:** Pure white `#FFFFFF` surface resting on the warm `#F7F4EE` base, rimmed with a 1px border of `#EADBC8`. Generous interior padding (`2rem`) with high-contrast serif headers.
- **Lifestyle & Personal Vignette Card:** Dual-tone container pairing lifestyle photography (natural canine candid or open-water swimming shot) with warm beige background strips and delicate italicised quotes.

### Chips & Badges
- **Specialty & Interest Badges:** Pill-shaped with `0.75rem` vertical and horizontal compactness. Rendered in `#F1ECE1` background with `#0F172A` text for certifications, or `#E8F2F8` background with `#0F172A` text for personal affinities.

### Form Inputs & Consult Scheduler
- **Input Fields:** Crisp `#FFFFFF` background, structured by a 1px border of `#EADBC8`. Focus states reveal an ambient glow with `#38BDF8` outline transition, maintaining calm visual stability.

### Lists & Credentials
- **Historical Milestones / Education:** Hairline horizontal rules in `rgba(15, 23, 42, 0.08)`. Left-aligned year indices set in `label-sm` alongside Playfair Display entry headers and clean sans-serif institution notations.